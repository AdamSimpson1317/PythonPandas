Portfolio 1
===================

This package is build as a part of the CSC1-34: Portfolio 1
Type 'Python hello_world' to see some useful information
