import sys
import platform

print("Hello World")



print(1, sys.version )
print(2, platform.python_implementation())
print(3, sys.executable)
